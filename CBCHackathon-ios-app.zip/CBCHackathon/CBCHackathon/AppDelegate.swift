//
//  AppDelegate.swift
//  CBCHackathon
//
//  Created by Shuangshuang Zhao on 2015-03-14.
//  Copyright (c) 2015 Shuangshuang Zhao. All rights reserved.
//

import UIKit

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {
    var window: UIWindow?
    func application(application: UIApplication, didFinishLaunchingWithOptions launchOptions: [NSObject: AnyObject]?) -> Bool {
        UINavigationBar.appearance().barTintColor = UIColor.brownColor()
        UINavigationBar.appearance().tintColor = UIColor.blackColor()
        return true
    }
    
    
    
}

