

import UIKit
import MapKit
import CoreLocation


class ViewController: UIViewController,MKMapViewDelegate,CLLocationManagerDelegate{
    
    var locationManager = CLLocationManager()
    var currentLocation : CLLocation!
 
    
    
    @IBAction func AddEvent(sender: UIBarButtonItem) {
        
        
        
        var location = self.currentLocation.coordinate
        var annotation = MKPointAnnotation()
        annotation.setCoordinate(location)
        annotation.title = "Allien"
        annotation.subtitle = "I saw an allien!!!"
        
        performSegueWithIdentifier("EventSegue", sender: annotation)
        mapView.addAnnotation(annotation)
    }
    
    

  
    
    @IBOutlet weak var mapView: MKMapView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.locationManager.delegate = self
        self.locationManager.requestAlwaysAuthorization()
        self.locationManager.desiredAccuracy = kCLLocationAccuracyBest
        self.locationManager.startUpdatingLocation()
        mapView.delegate = self
        
        
 
   
        
    }


    

    func locationManager(manager: CLLocationManager!, didUpdateLocations locations: [AnyObject]!) {
        currentLocation = self.locationManager.location
        var location = self.currentLocation.coordinate
        let span = MKCoordinateSpanMake(0.02, 0.02)
        let region = MKCoordinateRegion(center: location, span: span)
        mapView.setRegion(region, animated: true)
        mapView.showsUserLocation = true
        locationManager.stopUpdatingLocation()
        
        
        var annotation = MKPointAnnotation()
        location.latitude = location.latitude - 0.001
        location.longitude = location.longitude + 0.004
        annotation.setCoordinate(location)
        annotation.title = "CBCHackathon!!"
        annotation.subtitle = "Free Food!!"
        mapView.addAnnotation(annotation)
        
        location = self.currentLocation.coordinate
        var annotation2 = MKPointAnnotation()
        location.latitude = location.latitude + 0.001
        location.longitude = location.longitude - 0.002
        annotation2.setCoordinate(location)
        annotation2.title = "Fire!!"
        annotation2.subtitle = "Call 911!"
        mapView.addAnnotation(annotation2)
        
        
        location = self.currentLocation.coordinate
        var annotation3 = MKPointAnnotation()
        location.latitude = location.latitude + 0.002
        annotation3.setCoordinate(location)
        annotation3.title = "Vote Your President"
        annotation3.subtitle = "Politics"
        mapView.addAnnotation(annotation3)
        
        
        
    }
    
    func locationManager(manager: CLLocationManager!, didFailWithError error: NSError!) {
        println("Error while updating location" + error.localizedDescription)
    }
    
    
    
    func mapView(mapView: MKMapView!, annotationView view: MKAnnotationView!, calloutAccessoryControlTapped control: UIControl!) {
        if control == view.rightCalloutAccessoryView{
            //println(view.annotation.coordinate.latitude)
            
            
            if(view.annotation.title != "CBCHackathon!!" && view.annotation.title != "Fire!!" && view.annotation.title != "Vote Your President"){
                self.performSegueWithIdentifier("EventSegue", sender: view.annotation)
            }else{
                 self.performSegueWithIdentifier("TextSegue", sender: view.annotation.title)
            }
            
           
        }
    }
    

    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        
        if(segue.identifier == "TextSegue"){
            
            if let destinationVC = segue.destinationViewController as? TextViewController{
                var title = (sender as String)
                if(title == "CBCHackathon!!"){
                    destinationVC.content = "Eat/Sleep/Hack!!!\nEat/Sleep/Hack!!!\nEat/Sleep/Hack!!!\nEat/Sleep/Hack!!!\nEat/Sleep/Hack!!!\nEat/Sleep/Hack!!!\nEat/Sleep/Hack!!!\nEat/Sleep/Hack!!!\nEat/Sleep/Hack!!!\nEat/Sleep/Hack!!!\nEat/Sleep/Hack!!!\nEat/Sleep/Hack!!!\nEat/Sleep/Hack!!!\nEat/Sleep/Hack!!!\nEat/Sleep/Hack!!!\nEat/Sleep/Hack!!!\nEat/Sleep/Hack!!!\nEat/Sleep/Hack!!!\nEat/Sleep/Hack!!!\nEat/Sleep/Hack!!!\nEat/Sleep/Hack!!!\nEat/Sleep/Hack!!!\nEat/Sleep/Hack!!!\nEat/Sleep/Hack!!!\nEat/Sleep/Hack!!!\nEat/Sleep/Hack!!!\nEat/Sleep/Hack!!!\nEat/Sleep/Hack!!!\nEat/Sleep/Hack!!!\nEat/Sleep/Hack!!!\nEat/Sleep/Hack!!!\nEat/Sleep/Hack!!!\nEat/Sleep/Hack!!!\nEat/Sleep/Hack!!!\n"
                }else if(title == "Fire!!"){
                    destinationVC.content = "Be a hero!!!!\nBe a hero!!!!\nBe a hero!!!!\nBe a hero!!!!\nBe a hero!!!!\nBe a hero!!!!\nBe a hero!!!!\nBe a hero!!!!\nBe a hero!!!!\nBe a hero!!!!\nBe a hero!!!!\nBe a hero!!!!\nBe a hero!!!!\nBe a hero!!!!\nBe a hero!!!!\nBe a hero!!!!\nBe a hero!!!!\nBe a hero!!!!\nBe a hero!!!!\nBe a hero!!!!\nBe a hero!!!!\nBe a hero!!!!\nBe a hero!!!!\nBe a hero!!!!\nBe a hero!!!!\nBe a hero!!!!\nBe a hero!!!!\nBe a hero!!!!\nBe a hero!!!!\nBe a hero!!!!\nBe a hero!!!!\nBe a hero!!!!\nBe a hero!!!!\nBe a hero!!!!\nBe a hero!!!!\nBe a hero!!!!\nBe a hero!!!!\nBe a hero!!!!\n"
                }else if(title == "Vote Your President"){
                    destinationVC.content = "I am dictator! \nI am dictator! \nI am dictator! \nI am dictator! \nI am dictator! \nI am dictator! \nI am dictator! \nI am dictator! \nI am dictator! \nI am dictator! \nI am dictator! \nI am dictator! \nI am dictator! \nI am dictator! \nI am dictator! \nI am dictator! \nI am dictator! \nI am dictator! \nI am dictator! \nI am dictator! \nI am dictator! \nI am dictator! \nI am dictator! \nI am dictator! \nI am dictator! \nI am dictator! \nI am dictator! \nI am dictator! \nI am dictator! \nI am dictator! \nI am dictator! \nI am dictator! \nI am dictator! \n"
                }
            }
        }
        
        if(segue.identifier == "EventSegue"){
            if let destinationVC = segue.destinationViewController as? EventViewController{
                destinationVC.annotation = (sender as MKAnnotation)
                
            }
        }
        
        
       
    }
    
    

    func mapView(mapView: MKMapView!, viewForAnnotation annotation: MKAnnotation!) -> MKAnnotationView! {
        
        if annotation is MKUserLocation {
            return nil
        }
        let reuseId = "pin"
        var pinView = mapView.dequeueReusableAnnotationViewWithIdentifier(reuseId) as? MKPinAnnotationView
        if pinView == nil {
            pinView = MKPinAnnotationView(annotation: annotation, reuseIdentifier: reuseId)
            pinView!.canShowCallout = true
            pinView!.animatesDrop = true
            if(pinView?.annotation.title! == "CBCHackathon!!"){
                pinView!.pinColor = MKPinAnnotationColor.Green
                pinView?.draggable = false
                var button = UIButton.buttonWithType(UIButtonType.DetailDisclosure) as UIButton // button with info sign in it
                button.frame.size.width = 30
                button.frame.size.height = 30
                button.setImage(UIImage(named: "computer"), forState: .Normal)
                pinView?.rightCalloutAccessoryView = button
            }else if(pinView?.annotation.title == "Fire!!"){
                pinView!.pinColor = MKPinAnnotationColor.Red
                pinView?.draggable = false
                var button = UIButton.buttonWithType(UIButtonType.DetailDisclosure) as UIButton // button with info sign in it
                button.frame.size.width = 30
                button.frame.size.height = 30
                button.setImage(UIImage(named: "fire"), forState: .Normal)
                pinView?.rightCalloutAccessoryView = button
            }else if(pinView?.annotation.title == "Vote Your President"){
                pinView!.pinColor = MKPinAnnotationColor.Purple
                pinView?.draggable = false
                var button = UIButton.buttonWithType(UIButtonType.DetailDisclosure) as UIButton // button with info sign in it
                button.frame.size.width = 30
                button.frame.size.height = 30
                button.setImage(UIImage(named: "fist"), forState: .Normal)
                pinView?.rightCalloutAccessoryView = button
            }else if(pinView?.annotation.title == "Allien"){
                pinView!.pinColor = MKPinAnnotationColor.Red
                pinView?.draggable = true
                var button = UIButton.buttonWithType(UIButtonType.DetailDisclosure) as UIButton // button with info sign in it
                button.frame.size.width = 30
                button.frame.size.height = 30
                button.setImage(UIImage(named: "allien"), forState: .Normal)
                pinView?.rightCalloutAccessoryView = button
                
            }else{
                pinView!.pinColor = MKPinAnnotationColor.Red
                pinView?.draggable = true
            }
            
        }
 
        
     
        return pinView
        
    }

    
    
    
    
    
    
}

