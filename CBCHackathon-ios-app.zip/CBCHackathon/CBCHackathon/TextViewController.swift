//
//  TextViewController.swift
//  CBCHackathon
//
//  Created by Shuangshuang Zhao on 2015-03-14.
//  Copyright (c) 2015 Shuangshuang Zhao. All rights reserved.
//

import UIKit

class TextViewController: UIViewController {

    var content = ""
    
    @IBOutlet weak var textField: UITextView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        textField.text = content
        let bodyFontDescriptor = UIFontDescriptor.preferredFontDescriptorWithTextStyle(UIFontTextStyleBody)
        textField.font = UIFont(descriptor: bodyFontDescriptor, size: 0)
        textField.backgroundColor = UIColor.blueColor()
        textField.textColor = UIColor.whiteColor()
    }

    

}
